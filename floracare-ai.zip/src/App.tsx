import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Settings, 
  Rss, 
  FileText, 
  Plus, 
  RefreshCw, 
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  Users
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Tenant {
  id: number;
  name: string;
  wp_url: string;
  fb_page_id: string;
  ig_user_id: string;
}

interface Feed {
  id: number;
  tenant_id: number;
  tenant_name: string;
  name: string;
  url: string;
  last_scraped: string | null;
}

interface Post {
  id: number;
  tenant_name: string;
  title: string;
  status: string;
  published_at: string | null;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'tenants' | 'feeds' | 'posts'>('dashboard');
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [feeds, setFeeds] = useState<Feed[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(false);
  const [showTenantModal, setShowTenantModal] = useState(false);
  const [showFeedModal, setShowFeedModal] = useState(false);
  const [newTenant, setNewTenant] = useState({ 
    name: '', 
    wp_url: '', 
    fb_page_id: '', 
    ig_user_id: '', 
    meta_access_token: '',
    fb_scraper_user: '',
    fb_scraper_pass: ''
  });
  const [newFeed, setNewFeed] = useState({ tenant_id: '', name: '', url: '', type: 'rss', keywords: '' });

  const handleCreateTenant = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/tenants', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newTenant)
    });
    if (res.ok) {
      setShowTenantModal(false);
      fetchData();
    }
  };

  const handleCreateFeed = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/feeds', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newFeed)
    });
    if (res.ok) {
      setShowFeedModal(false);
      fetchData();
    }
  };

  const handleScrape = async () => {
    setLoading(true);
    const res = await fetch('/api/scrape', { method: 'POST' });
    if (res.ok) {
      const data = await res.json();
      alert(`Scrape complete! Found ${data.new_posts} new posts.`);
      fetchData();
    }
    setLoading(false);
  };

  const handlePublish = async (postId: number) => {
    setLoading(true);
    const res = await fetch(`/api/publish/${postId}`, { method: 'POST' });
    if (res.ok) {
      alert('Published successfully!');
      fetchData();
    } else {
      const data = await res.json();
      alert(`Publish failed: ${data.error}`);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [tRes, fRes, pRes] = await Promise.all([
        fetch('/api/tenants'),
        fetch('/api/feeds'),
        fetch('/api/posts')
      ]);
      
      if (tRes.ok) setTenants(await tRes.json());
      if (fRes.ok) setFeeds(await fRes.json());
      if (pRes.ok) setPosts(await pRes.json());
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderDashboard = () => (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-[#111] p-6 rounded-lg border border-white/5 neon-glow">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Total Clientes</h3>
          <Users className="w-5 h-5 text-neon-green" />
        </div>
        <p className="text-3xl font-bold text-white">{tenants.length}</p>
      </div>
      <div className="bg-[#111] p-6 rounded-lg border border-white/5 neon-glow">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Feeds Ativos</h3>
          <Rss className="w-5 h-5 text-neon-green" />
        </div>
        <p className="text-3xl font-bold text-white">{feeds.length}</p>
      </div>
      <div className="bg-[#111] p-6 rounded-lg border border-white/5 neon-glow">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Postagens</h3>
          <FileText className="w-5 h-5 text-neon-green" />
        </div>
        <p className="text-3xl font-bold text-white">{posts.length}</p>
      </div>

      <div className="md:col-span-3 bg-[#111] rounded-lg border border-white/5 overflow-hidden">
        <div className="p-4 border-b border-white/5 flex items-center justify-between bg-[#151515]">
          <h3 className="text-xs font-bold text-neon-green uppercase tracking-widest flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
            Atividade Recente
          </h3>
          <button onClick={fetchData} className="p-2 hover:bg-white/5 rounded-full transition-colors">
            <RefreshCw className={`w-4 h-4 text-zinc-400 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-[#1a1a1a] text-zinc-500 text-[10px] uppercase tracking-widest">
              <tr>
                <th className="px-6 py-3 font-bold">Portal</th>
                <th className="px-6 py-3 font-bold">Título</th>
                <th className="px-6 py-3 font-bold">Status</th>
                <th className="px-6 py-3 font-bold">Data</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {posts.map((post) => (
                <tr key={post.id} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-white">{post.tenant_name}</td>
                  <td className="px-6 py-4 text-sm text-zinc-400 truncate max-w-xs">{post.title}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-tighter ${
                        post.status === 'published' ? 'bg-neon-green/10 text-neon-green' : 'bg-amber-500/10 text-amber-500'
                      }`}>
                        {post.status}
                      </span>
                      {post.status !== 'published' && (
                        <button 
                          onClick={() => handlePublish(post.id)}
                          className="p-1 text-neon-green hover:bg-neon-green/10 rounded transition-colors"
                        >
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-zinc-500">
                    {post.published_at ? new Date(post.published_at).toLocaleDateString() : 'Pendente'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white font-sans selection:bg-neon-green selection:text-black">
      {/* Top Bar */}
      <header className="fixed top-0 left-0 w-full h-16 bg-[#0A0A0A] border-b border-neon-green/30 flex items-center justify-between px-8 z-30">
        <div className="flex items-center gap-4">
          <h1 className="text-xl font-black tracking-tighter text-neon-green">
            RSNEWS<span className="text-white">AUTO</span>
          </h1>
          <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest pt-1">v2.0 – PAINEL ADMIN</span>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-neon-green shadow-[0_0_8px_#00FF00]" />
            <span className="text-[10px] font-bold text-neon-green uppercase tracking-widest">ONLINE</span>
          </div>
          <button className="text-[10px] font-bold text-zinc-500 hover:text-white uppercase tracking-widest transition-colors">
            SAIR
          </button>
        </div>
      </header>

      {/* Sidebar */}
      <aside className="fixed left-0 top-16 h-[calc(100vh-64px)] w-64 bg-[#0A0A0A] border-r border-white/5 z-20">
        <nav className="p-4 space-y-1">
          <div className="px-4 py-2 text-[10px] font-bold text-zinc-600 uppercase tracking-widest">Navegação</div>
          <button 
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded text-xs font-bold uppercase tracking-widest transition-all ${
              activeTab === 'dashboard' ? 'bg-white/5 text-neon-green border-l-2 border-neon-green' : 'text-zinc-500 hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            Dashboard
          </button>
          <button 
            onClick={() => setActiveTab('tenants')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded text-xs font-bold uppercase tracking-widest transition-all ${
              activeTab === 'tenants' ? 'bg-white/5 text-neon-green border-l-2 border-neon-green' : 'text-zinc-500 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            Clientes
          </button>
          <button 
            onClick={() => setActiveTab('feeds')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded text-xs font-bold uppercase tracking-widest transition-all ${
              activeTab === 'feeds' ? 'bg-white/5 text-neon-green border-l-2 border-neon-green' : 'text-zinc-500 hover:text-white'
            }`}
          >
            <Rss className="w-4 h-4" />
            Fontes RSS
          </button>
          <button 
            onClick={() => setActiveTab('posts')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded text-xs font-bold uppercase tracking-widest transition-all ${
              activeTab === 'posts' ? 'bg-white/5 text-neon-green border-l-2 border-neon-green' : 'text-zinc-500 hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4" />
            Publicações
          </button>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="pl-64 pt-24 pr-8 pb-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-xs font-bold text-neon-green uppercase tracking-[0.3em] mb-1 flex items-center gap-2">
              <div className="w-1 h-4 bg-neon-green" />
              {activeTab}
            </h2>
          </div>
          <div className="flex gap-4">
            <button 
              onClick={handleScrape}
              disabled={loading}
              className="px-4 py-2 bg-white/5 border border-white/10 rounded text-[10px] font-bold uppercase tracking-widest hover:bg-white/10 transition-all disabled:opacity-50"
            >
              <RefreshCw className={`w-3 h-3 inline mr-2 ${loading ? 'animate-spin' : ''}`} />
              Sincronizar
            </button>
            <button 
              onClick={() => activeTab === 'tenants' ? setShowTenantModal(true) : setShowFeedModal(true)}
              className="px-6 py-2 bg-neon-green text-black rounded text-[10px] font-black uppercase tracking-widest hover:bg-[#00CC00] transition-all shadow-[0_0_15px_rgba(0,255,0,0.3)]"
            >
              <Plus className="w-3 h-3 inline mr-2" />
              NOVO
            </button>
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === 'dashboard' && renderDashboard()}
            
            {activeTab === 'tenants' && (
              <div className="bg-[#111] rounded-lg border border-white/5 overflow-hidden">
                <div className="p-4 border-b border-white/5 bg-[#151515]">
                  <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Clientes Cadastrados</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
                  {tenants.map(tenant => (
                    <div key={tenant.id} className="p-6 bg-[#151515] rounded-lg border border-white/5 hover:border-neon-green/30 transition-all group">
                      <div className="flex justify-between items-start mb-6">
                        <h4 className="font-black text-lg tracking-tighter text-white group-hover:text-neon-green transition-colors">{tenant.name}</h4>
                        <ExternalLink className="w-4 h-4 text-zinc-600 group-hover:text-neon-green transition-colors cursor-pointer" />
                      </div>
                      <div className="space-y-3">
                        <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest">
                          <span className="text-zinc-600">WordPress</span>
                          <span className="text-zinc-400 truncate ml-4">{tenant.wp_url}</span>
                        </div>
                        <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest">
                          <span className="text-zinc-600">FB Page</span>
                          <span className="text-zinc-400">{tenant.fb_page_id || '---'}</span>
                        </div>
                        <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest">
                          <span className="text-zinc-600">IG User</span>
                          <span className="text-zinc-400">{tenant.ig_user_id || '---'}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                  {tenants.length === 0 && (
                    <div className="col-span-full py-20 text-center text-zinc-600 text-xs font-bold uppercase tracking-widest">
                      Nenhum cliente encontrado
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'feeds' && (
              <div className="bg-[#111] rounded-lg border border-white/5 overflow-hidden">
                <div className="p-4 border-b border-white/5 bg-[#151515]">
                  <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Fontes de Dados</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead className="bg-[#1a1a1a] text-zinc-500 text-[10px] uppercase tracking-widest">
                      <tr>
                        <th className="px-6 py-3 font-bold">Portal</th>
                        <th className="px-6 py-3 font-bold">Tipo</th>
                        <th className="px-6 py-3 font-bold">Nome</th>
                        <th className="px-6 py-3 font-bold">Última Sincronia</th>
                        <th className="px-6 py-3 font-bold">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {feeds.map((feed) => (
                        <tr key={feed.id} className="hover:bg-white/5 transition-colors">
                          <td className="px-6 py-4 text-sm font-medium text-white">{feed.tenant_name}</td>
                          <td className="px-6 py-4">
                            <span className="px-2 py-0.5 bg-white/5 rounded text-[10px] font-bold text-zinc-400 uppercase tracking-widest">
                              {feed.type}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm text-zinc-400">{feed.name}</td>
                          <td className="px-6 py-4 text-sm text-zinc-500">
                            {feed.last_scraped ? new Date(feed.last_scraped).toLocaleString() : '---'}
                          </td>
                          <td className="px-6 py-4">
                            <button className="p-2 text-neon-green hover:bg-neon-green/10 rounded transition-colors">
                              <RefreshCw className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'posts' && (
               <div className="bg-[#111] rounded-lg border border-white/5 overflow-hidden">
               <div className="p-4 border-b border-white/5 bg-[#151515]">
                 <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Histórico de Publicações</h3>
               </div>
               <div className="overflow-x-auto">
                 <table className="w-full text-left">
                   <thead className="bg-[#1a1a1a] text-zinc-500 text-[10px] uppercase tracking-widest">
                     <tr>
                       <th className="px-6 py-3 font-bold">Portal</th>
                       <th className="px-6 py-3 font-bold">Título</th>
                       <th className="px-6 py-3 font-bold">Status</th>
                       <th className="px-6 py-3 font-bold">Data</th>
                     </tr>
                   </thead>
                   <tbody className="divide-y divide-white/5">
                     {posts.map((post) => (
                       <tr key={post.id} className="hover:bg-white/5 transition-colors">
                         <td className="px-6 py-4 text-sm font-medium text-white">{post.tenant_name}</td>
                         <td className="px-6 py-4 text-sm text-zinc-400 truncate max-w-md">{post.title}</td>
                         <td className="px-6 py-4">
                           <div className="flex items-center gap-2">
                             <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-tighter ${
                               post.status === 'published' ? 'bg-neon-green/10 text-neon-green' : 'bg-amber-500/10 text-amber-500'
                             }`}>
                               {post.status}
                             </span>
                             {post.status !== 'published' && (
                               <button 
                                 onClick={() => handlePublish(post.id)}
                                 className="p-1 text-neon-green hover:bg-neon-green/10 rounded transition-colors"
                               >
                                 <ExternalLink className="w-3 h-3" />
                               </button>
                             )}
                           </div>
                         </td>
                         <td className="px-6 py-4 text-sm text-zinc-500">
                           {post.published_at ? new Date(post.published_at).toLocaleString() : 'Pendente'}
                         </td>
                       </tr>
                     ))}
                   </tbody>
                 </table>
               </div>
             </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Modals */}
      <AnimatePresence>
        {showTenantModal && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#111] rounded-lg p-8 w-full max-w-lg border border-neon-green/30 shadow-[0_0_50px_rgba(0,255,0,0.1)]"
            >
              <h3 className="text-xl font-black tracking-tighter text-white mb-8 flex items-center gap-3">
                <div className="w-2 h-6 bg-neon-green" />
                NOVO CLIENTE
              </h3>
              <form onSubmit={handleCreateTenant} className="space-y-6">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Nome do Portal</label>
                  <input 
                    type="text" 
                    required
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-white/5 rounded text-sm focus:border-neon-green/50 outline-none transition-all"
                    value={newTenant.name}
                    onChange={e => setNewTenant({...newTenant, name: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">WordPress URL</label>
                  <input 
                    type="url" 
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-white/5 rounded text-sm focus:border-neon-green/50 outline-none transition-all"
                    value={newTenant.wp_url}
                    onChange={e => setNewTenant({...newTenant, wp_url: e.target.value})}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">FB Page ID</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-3 bg-[#1a1a1a] border border-white/5 rounded text-sm focus:border-neon-green/50 outline-none transition-all"
                      value={newTenant.fb_page_id}
                      onChange={e => setNewTenant({...newTenant, fb_page_id: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">IG User ID</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-3 bg-[#1a1a1a] border border-white/5 rounded text-sm focus:border-neon-green/50 outline-none transition-all"
                      value={newTenant.ig_user_id}
                      onChange={e => setNewTenant({...newTenant, ig_user_id: e.target.value})}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">FB Scraper User</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-3 bg-[#1a1a1a] border border-white/5 rounded text-sm focus:border-neon-green/50 outline-none transition-all"
                      value={newTenant.fb_scraper_user}
                      onChange={e => setNewTenant({...newTenant, fb_scraper_user: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">FB Scraper Pass</label>
                    <input 
                      type="password" 
                      className="w-full px-4 py-3 bg-[#1a1a1a] border border-white/5 rounded text-sm focus:border-neon-green/50 outline-none transition-all"
                      value={newTenant.fb_scraper_pass}
                      onChange={e => setNewTenant({...newTenant, fb_scraper_pass: e.target.value})}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Meta Access Token</label>
                  <textarea 
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-white/5 rounded text-sm focus:border-neon-green/50 outline-none transition-all h-24 resize-none"
                    value={newTenant.meta_access_token}
                    onChange={e => setNewTenant({...newTenant, meta_access_token: e.target.value})}
                  />
                </div>
                <div className="flex gap-4 pt-4">
                  <button 
                    type="button"
                    onClick={() => setShowTenantModal(false)}
                    className="flex-1 px-4 py-3 bg-white/5 text-zinc-500 rounded text-[10px] font-bold uppercase tracking-widest hover:bg-white/10 transition-all"
                  >
                    CANCELAR
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 px-4 py-3 bg-neon-green text-black rounded text-[10px] font-black uppercase tracking-widest hover:bg-[#00CC00] transition-all"
                  >
                    SALVAR CLIENTE
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}

        {showFeedModal && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#111] rounded-lg p-8 w-full max-w-lg border border-neon-green/30 shadow-[0_0_50px_rgba(0,255,0,0.1)]"
            >
              <h3 className="text-xl font-black tracking-tighter text-white mb-8 flex items-center gap-3">
                <div className="w-2 h-6 bg-neon-green" />
                NOVA FONTE
              </h3>
              <form onSubmit={handleCreateFeed} className="space-y-6">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Portal</label>
                  <select 
                    required
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-white/5 rounded text-sm focus:border-neon-green/50 outline-none transition-all appearance-none"
                    value={newFeed.tenant_id}
                    onChange={e => setNewFeed({...newFeed, tenant_id: e.target.value})}
                  >
                    <option value="">Selecione um portal</option>
                    {tenants.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Tipo de Fonte</label>
                    <select 
                      required
                      className="w-full px-4 py-3 bg-[#1a1a1a] border border-white/5 rounded text-sm focus:border-neon-green/50 outline-none transition-all appearance-none"
                      value={newFeed.type}
                      onChange={e => setNewFeed({...newFeed, type: e.target.value})}
                    >
                      <option value="rss">RSS Feed</option>
                      <option value="web">Site Comum (Web)</option>
                      <option value="facebook">Página Facebook</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Nome da Fonte</label>
                    <input 
                      type="text" 
                      required
                      className="w-full px-4 py-3 bg-[#1a1a1a] border border-white/5 rounded text-sm focus:border-neon-green/50 outline-none transition-all"
                      value={newFeed.name}
                      onChange={e => setNewFeed({...newFeed, name: e.target.value})}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">URL (Feed ou Site)</label>
                  <input 
                    type="url" 
                    required
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-white/5 rounded text-sm focus:border-neon-green/50 outline-none transition-all"
                    value={newFeed.url}
                    onChange={e => setNewFeed({...newFeed, url: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Palavras-Chave (separadas por vírgula)</label>
                  <input 
                    type="text" 
                    placeholder="ex: política, esporte"
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-white/5 rounded text-sm focus:border-neon-green/50 outline-none transition-all"
                    value={newFeed.keywords}
                    onChange={e => setNewFeed({...newFeed, keywords: e.target.value})}
                  />
                </div>
                <div className="flex gap-4 pt-4">
                  <button 
                    type="button"
                    onClick={() => setShowFeedModal(false)}
                    className="flex-1 px-4 py-3 bg-white/5 text-zinc-500 rounded text-[10px] font-bold uppercase tracking-widest hover:bg-white/10 transition-all"
                  >
                    CANCELAR
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 px-4 py-3 bg-neon-green text-black rounded text-[10px] font-black uppercase tracking-widest hover:bg-[#00CC00] transition-all"
                  >
                    SALVAR FONTE
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
